package za.mamamoney.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * MVC
 */
@WebServlet("/ConfirmationServlet")
public class ConfirmationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ConfirmationServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/Logout.jsp";
		// Menu 3 input data
		String opt = request.getParameter("opt");
		//Proceed to menu 4
		request.setAttribute("opt", opt);
		getServletContext().getRequestDispatcher(logout(opt,url)).forward(request, response);
	}
	public String logout(String opt,String url ) {
		String urlStr = url;
		if (opt == "ok") {
			
			url="/Index.jsp";
		}
		return url;
	}

}
