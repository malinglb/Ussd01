package za.mamamoney.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import za.mamamoney.cls.Account;
import za.mamamoney.cls.Beneficiary;

/**
 * MVC
 */
@WebServlet("/BeneficiaryServlet")
public class BeneficiaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    HttpSession hSession = null;
	public BeneficiaryServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String url = "/DisplaySubMenu.jsp";
		// Menu 2 input data
		String amount = request.getParameter("amount");
		//Retrieve HTTP Session from Menu 1
		hSession = request.getSession();
		Account account = (Account) hSession.getAttribute("account");
        
        String foreignAmt = convertAmtToLocalCurency(account.getCountry(),Integer.parseInt(amount));
       
        Beneficiary beneficiary = new Beneficiary(Double.parseDouble(amount),foreignAmt);
        // Proceed to Menu 3
        request.setAttribute("beneficiary", beneficiary);
        getServletContext().getRequestDispatcher(url).forward(request, response);
	}
	
	public String convertAmtToLocalCurency(String country, int amtInZAR) {
		String newAmt = new String();
		double kes = 42.2, mwk = 6.1;
		double calcvalue;
		try {
			if (country.equalsIgnoreCase("kenya")) {
				calcvalue = Math.round(amtInZAR * kes);
				newAmt = calcvalue + "KES";
			} else {
				calcvalue = Math.round(amtInZAR * mwk);
				newAmt = calcvalue+"MWK";
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return newAmt;
	}

}
