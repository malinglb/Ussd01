package za.mamamoney.cls;

import java.io.Serializable;

public class Beneficiary implements Serializable {

	private static final long serialVersionUID = 1L;
	private double amountInZar;
	private String amountInExchange;

	public Beneficiary() {
		super();
		this.amountInZar = 0.01;
		this.amountInExchange = "";
	}

	public Beneficiary(double amountInZar, String amountInExchange) {
		super();
		this.amountInZar = amountInZar;
		this.amountInExchange = amountInExchange;
	}

	public double getAmountInZar() {
		return amountInZar;
	}

	public void setAmountInZar(double amountInZar) {
		this.amountInZar = amountInZar;
	}

	public String getAmountInExchange() {
		return amountInExchange;
	}

	public void setAmountInExchange(String amountInExchange) {
		this.amountInExchange = amountInExchange;
	}

}
