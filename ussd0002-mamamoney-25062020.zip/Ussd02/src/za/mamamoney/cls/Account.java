package za.mamamoney.cls;

import java.io.Serializable;

public class Account implements Serializable {
	

	
	private static final long serialVersionUID = 1L;
	private String phone;
	private String country;
	private String countryCode;
	
	
	public Account() {
		super();
		this.country = "";
		this.countryCode = "";
		this.phone = "";
	}
	public Account(String country, String countryCode, String phone) {
		super();
		this.country = country;
		this.countryCode = countryCode;
		this.phone = phone;
	}
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryCode() {
		
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getPhone() {
		
		return phone;
	}
	public void setPhone(String phone) {
		if (phone.length() == 10) {
			phone = this.getCountryCode() + ""+ this.phone.substring(1,9);
		}
		this.phone = phone;
	}
	
	



}
