//Mysql db on ubuntu 19.4 terminal step by step process
1.0
sudo /usr/bin/mysql -u root -p
1.1 
CREATE DATABASE USSD02;
USE USSD02;

1.2 
CREATE TABLE account(
phone VARCHAR(20) NOT NULL,
countrycode VARCHAR(30) NOT NULL,
accountid INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY
);

1.3  Creating user specific to the db

CREATE USER 'dbadmin'@'localhost' IDENTIFIED BY 'password1';

1.4 View Users
SELECT User, HOST FROM mysql.user;

1.5 GRANT Permission to the MAIN USER of the DB

GRANT ALL PRIVILEGES ON TEST01.account TO 'dbadmin'@'localhost' IDENTIFIED BY 'password1';

or

GRANT ALL PRIVILEGES ON USSD02.account TO 'dbadmin'@'localhost' WITH GRANT OPTION;

1.6 db dump
mysqldump -u root -p USSD01 > ~/database-dump.sql;
